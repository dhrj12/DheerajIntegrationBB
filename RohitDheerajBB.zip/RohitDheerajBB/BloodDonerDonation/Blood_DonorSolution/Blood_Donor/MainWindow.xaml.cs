﻿using BusinessLogicLayer;
using EntityLayer;
using Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Blood_Donor
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DonorBL donor = new DonorBL();

                if (donor.ValidateBloodDonorData(txtDonorID.Text, txtDonorFName.Text, txtDonorLName.Text, txtDonorAdd.Text, txtDonorCity.Text, txtDonorMobile.Text))
                {
                    DonorEntities donorEntities = new DonorEntities()
                    {

                        BloodDonorID = txtDonorID.Text,

                        FirstName = txtDonorFName.Text,
                        LastName = txtDonorLName.Text,
                        Address = txtDonorAdd.Text,
                        City = txtDonorCity.Text,
                        Mobile = txtDonorMobile.Text,
                        BloodGroup = int.Parse(cmbBG.SelectedValue.ToString())
                    };

                    DonorBL dbl = new DonorBL();
                    if (donor.AddDonor(donorEntities))
                    {
                        MessageBox.Show("Details Added", "Blood Bank Management System");
                    }
                    else
                    {
                        MessageBox.Show("Details could not be added", "Blood Bank Management System");
                    }
                }
            }
            catch (BloodDonorException ex)
            {
                MessageBox.Show(ex.Message, "Warning");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Warning");
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                DonorBL db = new DonorBL();
                DataTable dt = db.GetCategories();
                if (dt != null)
                {
                    cmbBG.ItemsSource = dt.DefaultView;
                    cmbBG.DisplayMemberPath = "BG";
                    cmbBG.SelectedValuePath = "BGId";
                }
                else
                {
                    MessageBox.Show("Table is empty", "Blood Bank Management System");
                }
            }
            catch (BloodDonorException ex)
            {
                MessageBox.Show(ex.Message, "Blood Bank Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Blood Bank Management System");
            }
        }

        private void txtDonorID_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            BloodDonarDonation w = new BloodDonarDonation();
            w.Show();
        }
    }
}
